use Goblin_Master;

insert into personajes (nif,nombre,apellidos) 
value ('1','Aventurero','Garcia');

insert into personajes (nif,nombre,apellidos)
value ('2','Goblin','nothing');

insert into Usuarios (nif,nombre,apellidos,telefono,codigo_postal,edad,sexo)
values ('1','Oriol','Cordero','680698340','08940','19','1');

insert into Usuarios (nif,nombre,apellidos,telefono,codigo_postal,edad,sexo)
values ('2','Yahved','Fernandez','655403988','08940','21','1');

