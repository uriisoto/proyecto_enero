drop database if exists Goblin_Master;

create database if not exists Goblin_Master;

use Goblin_Master;


CREATE TABLE IF NOT EXISTS `personajes` (
  `nif` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Clave primaria',
  `nombre` varchar(50) NOT NULL COMMENT 'nombre personaje',
  `apellidos` varchar(100) NOT NULL COMMENT 'Apellidos personaje',
  PRIMARY KEY (`nif`),
  KEY `nombre` (`nombre`),
  FULLTEXT KEY `apellidos` (`apellidos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='tabla de personajes';


CREATE TABLE IF NOT EXISTS `Usuarios` (
  `nif` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Clave primaria',
  `nombre` varchar(50) NOT NULL COMMENT 'nombre',
  `apellidos` varchar(100) NOT NULL COMMENT 'Apellidos',
  `telefono` int(9) NOT NULL COMMENT 'móvil',
  `codigo_postal` int(5) DEFAULT NULL,
  `edad` int(3) DEFAULT NULL,
  `sexo` char(1) NOT NULL,
  PRIMARY KEY (`nif`),
  UNIQUE KEY `telefono` (`telefono`),
  KEY `nombre` (`nombre`),
  FULLTEXT KEY `apellidos` (`apellidos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='tabla de usuarios';


CREATE TABLE IF NOT EXISTS `Aventura` (
  `idaventura` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Clave primaria',
  `nombre` varchar(50) NOT NULL COMMENT 'nombre aventura',
  `descripcion` varchar(100) NOT NULL COMMENT 'Descripcion',
  PRIMARY KEY (`idaventura`),
  KEY `nombre` (`nombre`),
  FULLTEXT KEY `Descripcion` (`Descripcion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='tabla de la aventura';