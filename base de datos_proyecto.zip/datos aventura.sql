use Goblin_Master;

insert into Aventura (idaventura,nombre,descripcion)
values ('1','inicio','estas a punto de entrar en una cueva');

insert into Aventura (idaventura,nombre,descripcion)
values ('2','entrada','esta muy oscuro y no se ve nada');

insert into Aventura (idaventura,nombre,descripcion)
values ('3.1','caida','sigues avanzando sin ver nada');

insert into Aventura (idaventura,nombre,descripcion)
values ('4','mochila','buscas y encuentras una linterna');

insert into Aventura (idaventura,nombre,descripcion)
values ('5','caida','no notas suelo debajo y caes');

insert into Aventura (idaventura,nombre,descripcion)
values ('6','luz','alfin ves algo y hay dos caminos');

insert into Aventura (idaventura,nombre,descripcion)
values ('7','izquierda','se ve una leve luz');

insert into Aventura (idaventura,nombre,descripcion)
values ('8','derecha','el camino es totalmente oscuro');

insert into Aventura (idaventura,nombre,descripcion)
values ('9','luz','hay una base de Goblins y te atacan todos');

insert into Aventura (idaventura,nombre,descripcion)
values ('11','oscuro','te adentras y ves a un grupo de Goblins');

insert into Aventura (idaventura,nombre,descripcion)
values ('12','pasar','pasar de ellos y sseguir por el tunel');

insert into Aventura (idaventura,nombre,descripcion)
values ('13','examinar','decides busca algo de utilidad en la mochila');

insert into Aventura (idaventura,nombre,descripcion)
values ('14','buscas','encuentras un puñal y materiales para bombas');

insert into Aventura (idaventura,nombre,descripcion)
values ('15','bomba','contruyes una bomba para lanzarla contra ellos');

insert into Aventura (idaventura,nombre,descripcion)
values ('16','puñal','puedes cotar una cuerda para acabar con ellos');

insert into Aventura (idaventura,nombre,descripcion)
values ('17','explosion','tiras la bomba,los matas pero el techo cae');

insert into Aventura (idaventura,nombre,descripcion)
values ('18','corte','cortas la cuerda que sujeta unas cajas y mueren');

insert into Aventura (idaventura,nombre,descripcion)
values ('19','revisar','bajas y revisando te encuentras una espada robada');

insert into Aventura (idaventura,nombre,descripcion)
values ('20','pasar','decides seguir avanzando y aparece un Goblin');

insert into Aventura (idaventura,nombre,descripcion)
values ('21','puñetazo','le pegas un directo y es mas resistente y te ataca');

insert into Aventura (idaventura,nombre,descripcion)
values ('22','placaje','lo placas pero es agil y te ataca');

insert into Aventura (idaventura,nombre,descripcion)
values ('23','piedra','lanzas la piedra contra su cabeza y acabas con el ');

insert into Aventura (idaventura,nombre,descripcion)
values ('24','cadaver','examinas el cadaver y encuentras un zurrón');

insert into Aventura (idaventura,nombre,descripcion)
values ('25','boveda','tras seguir hacia delante la cueva se hace mucho mas grande');

insert into Aventura (idaventura,nombre,descripcion)
values ('26','fin','parece una mina antigua y decides invesigar...');
